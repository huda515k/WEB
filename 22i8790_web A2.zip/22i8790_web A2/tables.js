const apiKey = '87767364fc15ee9d69b4460c85b247ea'; // Your OpenWeather API key
const apiUrl = 'https://api.openweathermap.org/data/2.5/forecast';
const geminiApiUrl = 'https://api.gemini.ai/v1/chat';
const geminiApiKey = 'AIzaSyANQJl8TW3mbRdRq27UqUrmWXzfy1j9XHM'; // Your Gemini API Key

// DOM elements
const locationInput = document.getElementById('locationInput');
const searchButton = document.getElementById('searchButton');
const contentContainer = document.querySelector('.content-container');
const forecastTableBody = document.querySelector('#forecastTable tbody');
const paginationInfo = document.getElementById('pageInfo');
const prevPageButton = document.getElementById('prevPage');
const nextPageButton = document.getElementById('nextPage');
const chatbotInput = document.getElementById('chatbotInput');
const chatbotMessages = document.getElementById('chatbotMessages');
const sendChatButton = document.getElementById('sendChatButton');

let forecastData = [];
let currentPage = 1;
const itemsPerPage = 5;

// Fetch weather data when the search button is clicked
searchButton.addEventListener('click', () => {
    const location = locationInput.value.trim();
    if (location) {
        fetchWeatherForecast(location);
    } else {
        alert("Please enter a city name");
    }
});

// Function to fetch weather forecast data
function fetchWeatherForecast(location) {
    const url = `${apiUrl}?q=${location}&appid=${apiKey}&units=metric`;

    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error("Weather data not available for this city.");
            }
            return response.json();
        })
        .then(data => {
            forecastData = data.list; 
            displayForecast(currentPage);
            contentContainer.style.display = 'flex'; // Show the content container
        })
        .catch(error => {
            console.error('Error fetching weather data:', error);
            alert("Could not retrieve weather data. Please try again.");
        });
}

// Function to display the weather forecast for the current page
function displayForecast(page) {
    forecastTableBody.innerHTML = ''; // Clear previous entries

    const startIndex = (page - 1) * itemsPerPage;
    const endIndex = Math.min(startIndex + itemsPerPage, forecastData.length);

    for (let i = startIndex; i < endIndex; i++) {
        const forecast = forecastData[i];
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${new Date(forecast.dt * 1000).toLocaleDateString()}</td>
            <td>${Math.round(forecast.main.temp)}°C</td>
            <td>${forecast.weather[0].description}</td>
        `;
        forecastTableBody.appendChild(row);
    }

    paginationInfo.textContent = `Page ${page}`; // Display current page info
    prevPageButton.disabled = page === 1; // Disable previous button on the first page
    nextPageButton.disabled = endIndex >= forecastData.length; // Disable next button on the last page
}

// Event listeners for pagination buttons
prevPageButton.addEventListener('click', () => {
    if (currentPage > 1) {
        currentPage--;
        displayForecast(currentPage);
    }
});

nextPageButton.addEventListener('click', () => {
    if (currentPage * itemsPerPage < forecastData.length) {
        currentPage++;
        displayForecast(currentPage);
    }
});

// Handle sending messages in the chatbot
sendChatButton.addEventListener('click', () => {
    const userMessage = chatbotInput.value.trim();
    if (userMessage) {
        addChatbotMessage(userMessage, 'user');
        handleChatbotResponse(userMessage);
        chatbotInput.value = ''; // Clear input after sending
    }
});

// Function to add a message to the chatbot UI
function addChatbotMessage(message, sender) {
    const messageDiv = document.createElement('div');
    messageDiv.className = sender; // Class for styling
    messageDiv.textContent = message; // Set the message text
    chatbotMessages.appendChild(messageDiv);
    chatbotMessages.scrollTop = chatbotMessages.scrollHeight; // Scroll to the bottom
}

// Function to handle responses from the chatbot
function handleChatbotResponse(message) {
    if (message.toLowerCase().includes('weather')) {
        addChatbotMessage("Sure! Please enter a city name above to check the weather.", 'chatbot');
    } else {
        fetchGeminiResponse(message); // Fetch response from Gemini API
    }
}

// Function to fetch a response from the Gemini API
function fetchGeminiResponse(userMessage) {
    const requestOptions = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${geminiApiKey}`
        },
        body: JSON.stringify({
            message: userMessage
        })
    };

    fetch(geminiApiUrl, requestOptions)
        .then(response => {
            if (!response.ok) {
                throw new Error('Failed to fetch response from Gemini API');
            }
            return response.json();
        })
        .then(data => {
            const botResponse = data.response || 'Sorry, I don’t have an answer for that.';
            addChatbotMessage(botResponse, 'chatbot');
        })
        .catch(error => {
            console.error('Error fetching Gemini response:', error);
            addChatbotMessage('Sorry, I could not process your request.', 'chatbot');
        });
}
