const inputbtn = document.querySelector('.search');
const cityName = document.querySelector('.name');
const button = document.querySelector('button');

const temperature = document.querySelector('.temp');
const winds = document.querySelector('.wind');
const data = document.querySelector('.data');
const time = document.querySelector('.time');
const humidity = document.querySelector('.humidity');
const weather = document.querySelector('.condition');
const cloudy = document.querySelector('.cloudy');
const photo = document.querySelector('.icon');
const cityItems = document.querySelectorAll('.city');

const API_KEY = '&appid=db4ec88d903467c5b9dde56be249c059';
const API_LINK = 'https://api.openweathermap.org/data/2.5/weather?q=';
const API_UNITS = '&units=metric';

// Chart elements
let barChart, doughnutChart, lineChart;
const chartContainer = document.querySelector('.chart-container'); // Get the chart container

const getWeather = () => {
    const city = inputbtn.value || 'Polska';
    const URL = API_LINK + city + API_KEY + API_UNITS;

    axios.get(URL).then(res => {
        const temp = res.data.main.temp;
        const hum = res.data.main.humidity;
        const windSpeed = res.data.wind.speed;
        const feelsLike = res.data.main.feels_like;
        const status = Object.assign({}, ...res.data.weather);

        cityName.textContent = res.data.name;
        temperature.textContent = Math.floor(temp) + ' °C';
        humidity.textContent = hum + '%';
        weather.textContent = status.main;
        winds.textContent = windSpeed + ' km/H';
        cloudy.textContent = Math.floor(feelsLike) + ' °C';

        if (status.id >= 200 && status.id < 300) {
            photo.setAttribute('src', 'https://openweathermap.org/img/wn/11d@2x.png');
        } else if (status.id >= 300 && status.id < 400) {
            photo.setAttribute('src', 'https://openweathermap.org/img/wn/09d@2x.png');
        } else if (status.id >= 500 && status.id < 600) {
            photo.setAttribute('src', 'https://openweathermap.org/img/wn/10d@2x.png');
        } else if (status.id >= 600 && status.id < 700) {
            photo.setAttribute('src', 'https://openweathermap.org/img/wn/13d@2x.png');
        } else if (status.id >= 700 && status.id < 800) {
            photo.setAttribute('src', 'https://openweathermap.org/img/wn/50d@2x.png');
        } else if (status.id === 800) {
            photo.setAttribute('src', 'https://openweathermap.org/img/wn/01d@2x.png');
        } else if (status.id > 800 && status.id < 900) {
            photo.setAttribute('src', 'https://openweathermap.org/img/wn/03d@2x.png');
        } else {
            photo.setAttribute('src', 'https://openweathermap.org/img/wn/01d@2x.png');
        }

        fetchForecast(city); // Fetch forecast for charts
    });
};

document.getElementById('locationInput').addEventListener('submit', (event) => {
    event.preventDefault();
    getWeather();
    inputbtn.value = '';
});

cityItems.forEach(city => {
    city.addEventListener('click', () => {
        inputbtn.value = city.textContent;
    });
});

// Function to fetch and update the forecast data and charts
function fetchForecast(city) {
    const forecastUrl = `https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=db4ec88d903467c5b9dde56be249c059&units=metric`;

    axios.get(forecastUrl).then(res => {
        const temps = [];
        const weatherConditions = [];

        for (let i = 0; i < res.data.list.length; i += 8) {
            const forecast = res.data.list[i];
            temps.push(forecast.main.temp);
            weatherConditions.push(forecast.weather[0].main);
        }

        chartContainer.style.display = 'flex'; // Show the chart container

        updateCharts(temps, weatherConditions);
    });
}

function updateCharts(temps, weatherConditions) {
    const weatherCounts = weatherConditions.reduce((acc, condition) => {
        acc[condition] = (acc[condition] || 0) + 1;
        return acc;
    }, {});

    const labels = ["Day 1", "Day 2", "Day 3", "Day 4", "Day 5"];

    // Bar Chart
    const barCtx = document.getElementById('barChart').getContext('2d');
    if (barChart) barChart.destroy();
    barChart = new Chart(barCtx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Temperature (°C)',
                data: temps,
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        }
    });

    // Doughnut Chart
    const doughnutCtx = document.getElementById('doughnutChart').getContext('2d');
    if (doughnutChart) doughnutChart.destroy();
    doughnutChart = new Chart(doughnutCtx, {
        type: 'doughnut',
        data: {
            labels: Object.keys(weatherCounts),
            datasets: [{
                data: Object.values(weatherCounts),
                backgroundColor: ['rgba(255, 99, 132, 0.2)', 'rgba(54, 162, 235, 0.2)', 'rgba(255, 206, 86, 0.2)'],
                borderColor: ['rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)', 'rgba(255, 206, 86, 1)'],
                borderWidth: 1
            }]
        }
    });

    // Line Chart
    const lineCtx = document.getElementById('lineChart').getContext('2d');
    if (lineChart) lineChart.destroy();
    lineChart = new Chart(lineCtx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Temperature (°C)',
                data: temps,
                fill: false,
                borderColor: 'rgba(153, 102, 255, 1)',
                tension: 0.1
            }]
        }
    });
}